update person natural join client
set address_street = 'Rua da Bela Vista', address_city = 'Lisboa', address_zip = '2695'
where name = 'John Smith';
