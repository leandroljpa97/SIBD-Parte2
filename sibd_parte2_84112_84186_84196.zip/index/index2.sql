create index idx_indicator_units_reference_value on indicator(units, reference_value);
